<?php declare(strict_types=1);

$app->add(new \CorsSlim\CorsSlim());
