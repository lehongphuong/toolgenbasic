<?php 
	switch ($data->what) { 
        //******************staff************************
        // staff(id,username,password,status,startdate,permission)
        // Get all data from staff
        case 20: {
            $sql = "SELECT * FROM staff";
            break;
        }

        // Insert data to staff
        case 21: {
            $sql = "INSERT INTO staff(username,password,status,startdate,permission)
            		VALUES('$data->username','$data->password','$data->status','$data->startdate','$data->permission')";
            break;
        }

        // Update data staff
        case 22: {
            $sql = "UPDATE staff SET username='$data->username', password='$data->password', status='$data->status', startdate='$data->startdate', permission = '$data->permission'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of staff
        case 23: {
            $sql = "DELETE FROM staff
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id staff
        case 24: {
            $sql = "SELECT * FROM staff
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) staff
        case 25: {
            $sql = "SELECT * FROM staff
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of staff
        case 26: {
            $sql = "SELECT COUNT(1) FROM staff ";
            break;
        }

	}
?> 
