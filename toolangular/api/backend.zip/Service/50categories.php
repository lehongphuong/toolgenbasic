<?php 
	switch ($data->what) { 
        //******************categories************************
        // categories(id,type,amount,comission)
        // Get all data from categories
        case 50: {
            $sql = "SELECT * FROM categories";
            break;
        }

        // Insert data to categories
        case 51: {
            $sql = "INSERT INTO categories(type,amount,comission)
            		VALUES('$data->type','$data->amount','$data->comission')";
            break;
        }

        // Update data categories
        case 52: {
            $sql = "UPDATE categories SET type='$data->type', amount='$data->amount', comission = '$data->comission'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of categories
        case 53: {
            $sql = "DELETE FROM categories
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id categories
        case 54: {
            $sql = "SELECT * FROM categories
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) categories
        case 55: {
            $sql = "SELECT * FROM categories
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of categories
        case 56: {
            $sql = "SELECT COUNT(1) FROM categories ";
            break;
        }

	}
?> 
