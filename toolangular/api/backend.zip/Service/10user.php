<?php 
	switch ($data->what) { 
        //******************user************************
        // user(id,username,password,address,phone,born,sex,email)
        // Get all data from user
        case 10: {
            $sql = "SELECT * FROM user";
            break;
        }

        // Insert data to user
        case 11: {
            $sql = "INSERT INTO user(username,password,address,phone,born,sex,email)
            		VALUES('$data->username','$data->password','$data->address','$data->phone','$data->born','$data->sex','$data->email')";
            break;
        }

        // Update data user
        case 12: {
            $sql = "UPDATE user SET username='$data->username', password='$data->password', address='$data->address', phone='$data->phone', born='$data->born', sex='$data->sex', email = '$data->email'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of user
        case 13: {
            $sql = "DELETE FROM user
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id user
        case 14: {
            $sql = "SELECT * FROM user
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) user
        case 15: {
            $sql = "SELECT * FROM user
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of user
        case 16: {
            $sql = "SELECT COUNT(1) FROM user ";
            break;
        }

	}
?> 
