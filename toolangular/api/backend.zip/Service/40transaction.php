<?php 
	switch ($data->what) { 
        //******************transaction************************
        // transaction(id,idaccount,idstaff,status,type,startdate,money,comment)
        // Get all data from transaction
        case 40: {
            $sql = "SELECT * FROM transaction";
            break;
        }

        // Insert data to transaction
        case 41: {
            $sql = "INSERT INTO transaction(idaccount,idstaff,status,type,startdate,money,comment)
            		VALUES('$data->idaccount','$data->idstaff','$data->status','$data->type','$data->startdate','$data->money','$data->comment')";
            break;
        }

        // Update data transaction
        case 42: {
            $sql = "UPDATE transaction SET idaccount='$data->idaccount', idstaff='$data->idstaff', status='$data->status', type='$data->type', startdate='$data->startdate', money='$data->money', comment = '$data->comment'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of transaction
        case 43: {
            $sql = "DELETE FROM transaction
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id transaction
        case 44: {
            $sql = "SELECT * FROM transaction
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) transaction
        case 45: {
            $sql = "SELECT * FROM transaction
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of transaction
        case 46: {
            $sql = "SELECT COUNT(1) FROM transaction ";
            break;
        }

	}
?> 
