<?php 
	switch ($data->what) { 
        //******************account************************
        // account(id,iduser,username,password,status,createdate,numberlot,money)
        // Get all data from account
        case 30: {
            $sql = "SELECT * FROM account";
            break;
        }

        // Insert data to account
        case 31: {
            $sql = "INSERT INTO account(iduser,username,password,status,createdate,numberlot,money)
            		VALUES('$data->iduser','$data->username','$data->password','$data->status','$data->createdate','$data->numberlot','$data->money')";
            break;
        }

        // Update data account
        case 32: {
            $sql = "UPDATE account SET iduser='$data->iduser', username='$data->username', password='$data->password', status='$data->status', createdate='$data->createdate', numberlot='$data->numberlot', money = '$data->money'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of account
        case 33: {
            $sql = "DELETE FROM account
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id account
        case 34: {
            $sql = "SELECT * FROM account
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) account
        case 35: {
            $sql = "SELECT * FROM account
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of account
        case 36: {
            $sql = "SELECT COUNT(1) FROM account ";
            break;
        }

	}
?> 
