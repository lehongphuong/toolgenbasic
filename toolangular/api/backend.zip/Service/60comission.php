<?php 
	switch ($data->what) { 
        //******************comission************************
        // comission(id,iduser,idstaff,money)
        // Get all data from comission
        case 60: {
            $sql = "SELECT * FROM comission";
            break;
        }

        // Insert data to comission
        case 61: {
            $sql = "INSERT INTO comission(iduser,idstaff,money)
            		VALUES('$data->iduser','$data->idstaff','$data->money')";
            break;
        }

        // Update data comission
        case 62: {
            $sql = "UPDATE comission SET iduser='$data->iduser', idstaff='$data->idstaff', money = '$data->money'
            		WHERE id='$data->id'";
            break;
        }

        // Delete data of comission
        case 63: {
            $sql = "DELETE FROM comission
            		WHERE id IN($data->id)";
            break;
        }

        // Find data with id comission
        case 64: {
            $sql = "SELECT * FROM comission
            		WHERE id='$data->id'";
            break;
        }

        // Select with pagination(offset, number-item-in-page) comission
        case 65: {
            $sql = "SELECT * FROM comission
            		LIMIT $data->offset, $data->limit";
            break;
        }

        // Count number item of comission
        case 66: {
            $sql = "SELECT COUNT(1) FROM comission ";
            break;
        }

	}
?> 
