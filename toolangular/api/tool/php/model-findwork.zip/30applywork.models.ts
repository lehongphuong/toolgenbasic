export class Applywork {
    id?: Number;
    idcandidate?: string;
    idjobs?: string;
    startdate?: string;
    status?: string;
}
