export class Applysave {
    id?: Number;
    idcandidate?: string;
    idjobs?: string;
    startdate?: string;
}
