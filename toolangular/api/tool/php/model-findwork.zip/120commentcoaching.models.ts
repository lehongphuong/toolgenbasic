export class Commentcoaching {
    id?: Number;
    idcandidate?: string;
    idcoaching?: string;
    startdate?: string;
    content?: string;
    star?: string;
    approve?: string;
}
