export class Message {
    id?: Number;
    idcandidate?: string;
    idcompany?: string;
    startdate?: string;
    content?: string;
}
