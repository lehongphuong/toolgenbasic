export class Staff {
    id?: Number;
    username?: string;
    password?: string;
    phone?: string;
    born?: string;
    address?: string;
    sex?: string;
    wokingstatus?: string;
    role?: string;
}
