export class Career {
    id?: Number;
    name?: string;
}
