export class Package {
    id?: Number;
    idcoaching?: string;
    name?: string;
    price?: string;
}
