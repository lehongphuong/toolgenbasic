export class Jobs {
    id?: Number;
    idcompany?: string;
    position?: string;
    amountrecruitment?: string;
    positionrecruitment?: string;
    salary?: string;
    asomission?: string;
    addresswork?: string;
    career?: string;
    descriptionwork?: string;
    benefit?: string;
    exprience?: string;
    academiclevel?: string;
    sex?: string;
    languagelevel?: string;
    deadlineapply?: string;
    requirementwork?: string;
    requirementdocument?: string;
    fullname?: string;
    phone?: string;
    email?: string;
    positioncontact?: string;
    point?: string;
    startads?: string;
    endads?: string;
}
