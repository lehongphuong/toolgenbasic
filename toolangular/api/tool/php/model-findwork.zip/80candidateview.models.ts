export class Candidateview {
    id?: Number;
    idcandidate?: string;
    idcompany?: string;
    startdate?: string;
    phone?: string;
    point?: string;
}
