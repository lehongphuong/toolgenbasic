export class Coaching {
    id?: Number;
    fullname?: string;
    born?: string;
    sex?: string;
    phone?: string;
    address?: string;
    about?: string;
    skill?: string;
    avatar?: string;
}
