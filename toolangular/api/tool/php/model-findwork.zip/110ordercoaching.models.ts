export class Ordercoaching {
    id?: Number;
    idcoaching?: string;
    idcandidate?: string;
    idpackage?: string;
    startdate?: string;
    startconnect?: string;
    statuspayment?: string;
    amount?: string;
}
