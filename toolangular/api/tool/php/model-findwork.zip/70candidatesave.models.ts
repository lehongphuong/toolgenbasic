export class Candidatesave {
    id?: Number;
    idcandidate?: string;
    idcompany?: string;
    startdate?: string;
}
