export class Company {
    id?: Number;
    email?: string;
    password?: string;
    avatar?: string;
    fullname?: string;
    phone?: string;
    companyname?: string;
    companyphone?: string;
    personalscale?: string;
    address?: string;
    city?: string;
    point?: string;
    website?: string;
    career?: string;
    about?: string;
    logo?: string;
    bussinesslicence?: string;
    position?: string;
    personalemail?: string;
    point?: string;
    startads?: string;
    endads?: string;
    banner?: string;
    pointbanner?: string;
    startadsbanner?: string;
    endadsbanner?: string;
}
